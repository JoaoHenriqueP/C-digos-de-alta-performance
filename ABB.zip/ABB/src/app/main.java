package app;

import java.util.Scanner;

import arvores.ABBint;

public class main {

	public static void main(String[] args) {
		ABBint abb = new ABBint();

		Scanner le = new Scanner(System.in);
		int opt, dado;
		do {
			System.out.println("0.Sair");
			System.out.println("1.Inserir");
			System.out.println("2.Apresentar");
			System.out.println("3.Quantidade");
			System.out.println("4.Consultar");
			opt = le.nextInt();
			if (opt == 1) {
				System.out.println("Digite o dado:");
				dado = le.nextInt();
				abb.root = abb.inserir(abb.root, dado);
			} else if (opt == 2) {
				System.out.println("Apresentando:");
				abb.inOrdem(abb.root);
			} else if (opt == 3) {
				int contador = 0;
				System.out.println(abb.contaNos(abb.root, contador));
			} else if (opt == 4) {
				System.out.println("Digite o dado que será consultado:");
				int consulta = le.nextInt();
				System.out.println(abb.consulta(abb.root, consulta));
			} else if (opt != 0) {
				System.out.println("Erro");
			}
		} while (opt != 0);

	}

}
